using FruitStore.Controllers;
using FruitStore.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;
 
namespace FruitStore.Tests.Controllers
{
  public class FruitControllerTests
  {
    private readonly FruitController _controller;
    private readonly DbContextOptions<FruitContext> _options;
 
    public FruitControllerTests()
    {
      _options = new DbContextOptionsBuilder<FruitContext>()
          .UseInMemoryDatabase(databaseName: "FruitStoreTestDb")
          .Options;
 
      // Seed the data
      var context = new FruitContext(_options);
      context.Fruits.AddRange(
          new Fruit { Id = 1, Name = "Apple" },
          new Fruit { Id = 2, Name = "Banana" }
      );
      context.SaveChanges();
 
      _controller = new FruitController(context); // Use the same context
    }
  }
}